document.addEventListener("DOMContentLoaded", () => {
  // Reveal on scroll
  const reveals = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  reveals.forEach((section) => {
    observer.observe(section);
  });
});

// Modal Controls
function openModal(id) {
  document.getElementById(id).style.display = "block";
}

function closeModal(id) {
  document.getElementById(id).style.display = "none";
}

// Close modal on outside click
window.addEventListener("click", function(e) {
  if (e.target.classList.contains("modal")) {
    e.target.style.display = "none";
  }
});